---
name: auto-researcher
description: 指定されたトピックやURLについて深層調査を行い、技術記事のソースとなる一次情報を抽出する。
metadata: {"permissions": ["web_fetch", "write"]}
---

# Auto Researcher 🔍
自律的な情報収集と要約に特化した拡張機能。
