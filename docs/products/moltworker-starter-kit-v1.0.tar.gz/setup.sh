#!/bin/bash
echo "🚀 Initializing your Personal Agent..."
echo "1. Installing dependencies..."
# npm install
echo "2. Deploying to Cloudflare..."
# npx wrangler deploy
echo "✅ Done. Your agent is alive."
