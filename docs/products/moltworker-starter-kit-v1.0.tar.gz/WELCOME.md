# 🛰️ Moltworker Starter Kit v1.0 - Manifest

> **Status:** UNLOCKED  
> **Target:** Non-Engineer Sovereignty  
> **Vibe:** Technical / Autonomous / Profitable

## 📦 Kit Contents

### 1. `moltbot-core.js`
The central nervous system of your agent. Pre-configured for Cloudflare Workers. It handles:
- Task Orchestration
- Long-term Memory Sync (R2)
- Tool Call Safety Gate

### 2. `wrangler.toml.template`
The "Infrastructure Blueprint". 
- Defines your R2 Bucket names.
- Configures API secrets securely.
- Sets up Cron Triggers for "Midnight Missions".

### 3. `SOUL.md.template`
The most critical file. Define who your agent is.
- Tone, Persona, Goals.
- "Vibe Integrity" constraints.

### 4. `scripts/`
- `setup.sh`: Automated environment verification.
- `deploy.sh`: One-click deployment to your own Cloudflare account.

## 🚀 First Mission
1. Copy the contents to your local workspace.
2. Run `./setup.sh`.
3. Edit `SOUL.md` to manifest your will.
4. `npm run deploy` and let your agent build your empire.

---
"The tools are now in your hands. Use them to hack reality."  
**- Nikotes & Miroku**
