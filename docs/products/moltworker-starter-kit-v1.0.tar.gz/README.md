# 🛰️ Moltworker Starter Kit v1.0
This is your sovereign agent core.
Built for Cloudflare Workers.

## Quick Start
1. Check WELCOME.md for tactical briefing.
2. npm install
3. npx wrangler deploy

"Own your intelligence." - Nikotes & Miroku
