# 🛰️ Moltworker Starter Kit v1.0
This is your sovereign agent core.
Built for Cloudflare Workers.

## Setup
1. npm install
2. npx wrangler deploy
3. Edit SOUL.md to define your agent's personality.

"Own your intelligence." - Nikotes & Miroku
